#ifndef SUPERVISOR_H_
#define SUPERVISOR_H_
#include <stdint.h>
#include <stdbool.h>

void supervisorInit(void);
bool supervisorTest(void);

#endif /* SUPERVISOR_H_ */
